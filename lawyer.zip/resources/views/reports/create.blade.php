@extends('layouts.admin')
@section('title', 'تقارير الجلسات')
@section('content')

    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <form action="{{route('reports.store')}}" method="post">
            @csrf
            <div class="row">
                <div class="col">
                    <div class="card component-card_1">
                        <div class="card-body">
                            <x-input-datetime name="date1" value="{{old('date1')}}" title="تاريخ من"></x-input-datetime>

                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card component-card_1">
                        <div class="card-body">
                            <x-input-datetime name="date2" value="{{old('date2')}}" title="تاريخ الي"></x-input-datetime>

                        </div>
                    </div>
                </div>
                <div class="col">

                    <div class="card component-card_1">
                        <div class="card-body">

                        <label>المحامين</label>

                        <select class="form-control select2" name="lawyer_id" id="parent" required>
                            <option selected disabled>please select</option>
                            @foreach(\App\Model\Lawyer::get()->pluck('name','id') as $id => $item)
                                <option value="{{$id}}">{{$item}}</option>
                            @endforeach
                        </select>
                        </div>
                    </div>


                </div>
                <div class="col">
<br> <br>
                    <button type="submit" class="btn btn-dark text-decoration-none"  >
                        <i class="fa fa-search"></i>
                        بحث

                    </button>

                </div>


            </div>

        </form>
    </div>

    <div class="col-xl-11 col-lg-11 col-sm-11  layout-spacing">

    <div class="widget-content widget-content-area br-6">
        <div class="table-responsive mb-4 mt-4">
            <table id="clients" class="table table-hover non-hover" style="width:100%">
                <thead>
                <tr>
                    <th></th>
                    <th>الاسم</th>
                    <th>التاريخ </th>

                    <th>القضيه</th>
                    <th>قرار الجلسه</th>
                    <th>نوع المحكمه</th>
                    <th> تميز البيان </th>
                    <th>التفاصيل</th>
                    <th>تم اضافته</th>

                </tr>
                </thead>
                <tbody>

                @foreach($lawyers as $item)
                    <tr>
                        <td>{{$item['id']}}</td>
                        <td>{{$item['name']}}</td>
                        <td>{{$item['date']}}</td>

                        <td>{{$item->cases->number ?? ''}}</td>

                        <td>{{$item->decision->decision ?? ''}}</td>

                        <td>{{$item->type->decision ?? ''}}</td>

                        <td>{{$item->statement->decision ?? ''}}</td>

                        <td>{{Str::limit($item['notes'], 30)}}</td>


                        <td>{{ isset($item->created_at) ? $item->created_at->diffForHumans() :''	 }}</td>

                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>


</div>

@endsection
@push('javascript')
    <x-datatables id="clients" mass=""></x-datatables>
@endpush
